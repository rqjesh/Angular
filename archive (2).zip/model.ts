export class Endpoints {
    
    serviceKey : string;
    serviceEndpointURL : String;
    createdBy : string;
    createdDate : string;
    modifiedBy : string;
    modifiedDate : string;
    contact : string;
    healthCheckURL : string;
    availibility : string;
    id : number;

    constructor(serviceKey : string,serviceEndpointURL : String,createdBy : string,createdDate : string,modifiedBy : string,modifiedDate : string,contact : string,healthCheckURL : string,availibility : string,id : number){
        this.id = id;
        this.availibility = availibility;
        this.healthCheckURL = healthCheckURL;
        this.contact = contact;
        this.modifiedDate = modifiedDate;
        this.modifiedBy = modifiedBy;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.serviceEndpointURL = serviceEndpointURL;
        this.serviceKey = serviceKey;
    }
}
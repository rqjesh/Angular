export class Endpoints {
    
    serviceKey : string;
    application : string;
    status : string;
    serviceEndpointURL : String;
    createdBy : string;
    createdDate : string;
    modifiedBy : string;
    modifiedDate : string;
    contact : string;
    healthCheckURL : string;
    availability : string;
    id : number;

    constructor(serviceKey : string,application : string,status:string,serviceEndpointURL : String,createdBy : string,createdDate : string,modifiedBy : string,modifiedDate : string,contact : string,healthCheckURL : string,availability : string,id : number){
        this.id = id;
        this.application = application;
        this.status = status;
        this.availability = availability;
        this.healthCheckURL = healthCheckURL;
        this.contact = contact;
        this.modifiedDate = modifiedDate;
        this.modifiedBy = modifiedBy;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.serviceEndpointURL = serviceEndpointURL;
        this.serviceKey = serviceKey;
    }
}
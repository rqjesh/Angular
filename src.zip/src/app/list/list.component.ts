import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Endpoints} from '../model';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  active = 1;
  rowData : Endpoints[]= [];
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.healthcheck();
  }

  columnDefs = [
    {headerName: 'id', field: 'id'},
    {headerName: 'status', field: 'status'},
    {headerName: 'application', field: 'application'},
    {headerName: 'contact', field: 'contac'},
    {headerName: 'healthCheckURL', field: 'healthCheckURL'},
    {headerName: 'modifiedDate', field: 'modifiedDate'},
    {headerName: 'modifiedBy', field: 'modifiedBy'},
    {headerName: 'createdDate', field: 'createdDate'},
    {headerName: 'createdBy', field: 'createdBy'},
    {headerName: 'availability', field: 'availability'},
    {headerName: 'serviceEndpointURL', field: 'serviceEndpointURL'},
    {headerName: 'serviceKey', field: 'serviceKey'}
  ];

  healthcheck(){
    let response = this.http.get<Endpoints[]>("http://localhost:8080/dashboard/healthService/availabilityEndpoints");
    response.subscribe((data : Endpoints[])=>this.rowData=data);
  }
}

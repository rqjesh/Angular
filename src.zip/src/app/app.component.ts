import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {MatIconModule} from '@angular/material/icon';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'DESTUI';

  constructor(private router:Router){

  }
  ngOnInit() {

  }
  listView($event){
    this.router.navigate(['/list']);
  }
  dashboard($event){
    this.router.navigate(['/dashboard']);
  }
}

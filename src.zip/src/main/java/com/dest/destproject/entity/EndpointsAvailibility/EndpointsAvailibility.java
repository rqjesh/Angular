package com.dest.destproject.entity.EndpointsAvailibility;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
@Table(name = "DEST_SERVICE_ENDPOINTS_AVAILIBILITY")
public class EndpointsAvailibility {

    @Id
    @Column(name = "ID")
    private int Id;
    @Column(name = "SERVICE_ENDPOINT_URL")
    private String serviceEndpointURL;
    @Column(name = "AVAILIBILITY")
    private String availibility;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "CREATED_DATE")
    private String createdDate;
    @Column(name = "MODIFIED_BY")
    private String modifiedBy;
    @Column(name = "MODIFIED_DATE")
    private String modifiedDate;

    public EndpointsAvailibility(int id, String serviceEndpointURL, String availibility, String createdBy, String createdDate, String modifiedBy, String modifiedDate) {
        Id = id;
        this.serviceEndpointURL = serviceEndpointURL;
        this.availibility = availibility;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
    }

    public EndpointsAvailibility() {
        super();
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getServiceEndpointURL() {
        return serviceEndpointURL;
    }

    public void setServiceEndpointURL(String serviceEndpointURL) {
        this.serviceEndpointURL = serviceEndpointURL;
    }

    public String getAvailibility() {
        return availibility;
    }

    public void setAvailibility(String availibility) {
        this.availibility = availibility;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    @Override
    public String toString() {
        return "EndpointsAvailibility{" +
                "Id=" + Id +
                ", serviceEndpointURL='" + serviceEndpointURL + '\'' +
                ", availibility='" + availibility + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", modifiedBy='" + modifiedBy + '\'' +
                ", modifiedDate='" + modifiedDate + '\'' +
                '}';
    }
}

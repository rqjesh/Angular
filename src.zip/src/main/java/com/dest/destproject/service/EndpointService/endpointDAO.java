package com.dest.destproject.service.EndpointService;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface endpointDAO {

    public List<ServiceEndpoints> getEndpoints();
}

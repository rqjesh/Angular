package com.dest.destproject.service.HealthService;

import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;

import java.util.List;

public interface HealthServiceDAO {

    public List<ServiceEndpoints> HealthCheck();
    public List<ServiceEndpoints> EndpointCheck();
    public List<ServiceEndpoints> PingCheck();
}

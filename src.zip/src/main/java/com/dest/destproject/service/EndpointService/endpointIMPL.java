package com.dest.destproject.service.EndpointService;

import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import org.hibernate.query.Query;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class endpointIMPL implements endpointDAO {
    @Override
    public List<ServiceEndpoints> getEndpoints() {

        try {

            Configuration config = new Configuration().configure("persistence-cfg.xml").addAnnotatedClass(ServiceEndpoints.class);
            SessionFactory sf = config.buildSessionFactory();
            Session s = sf.openSession();
            Transaction t = s.beginTransaction();
            Query query = s.createQuery("from ServiceEndpoints");
            List<ServiceEndpoints> endpointsList = query.list();
            t.commit();
            s.close();
            return endpointsList;
        }
        catch (Exception e)
        {
            System.out.println("Error Connecting to Database");
            return null;
        }
    }

}

package com.dest.destproject.service.AvailibilityService;

import com.dest.destproject.entity.EndpointsAvailibility.EndpointsAvailibility;

import java.util.List;

public interface availibilityDAO {

    public List<EndpointsAvailibility> getAvailibility();
}

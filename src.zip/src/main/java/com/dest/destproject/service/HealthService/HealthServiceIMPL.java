package com.dest.destproject.service.HealthService;

import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.HttpURLConnection;
import java.net.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

@Service
public class HealthServiceIMPL implements HealthServiceDAO {


    @Override
    public List<ServiceEndpoints> HealthCheck() {

        try {

            Configuration config = new Configuration().configure("persistence-cfg.xml").addAnnotatedClass(ServiceEndpoints.class);
            SessionFactory sf = config.buildSessionFactory();
            Session s = sf.openSession();
            Transaction t = s.beginTransaction();
            Query query = s.createQuery("from ServiceEndpoints");
            List<ServiceEndpoints> endpointsList = query.list();
            for(ServiceEndpoints endpoints : endpointsList){
                RestTemplate restTemplate = new RestTemplate();
                int statusCode = 0;
                try {
                    ResponseEntity<String> response = restTemplate.getForEntity( "http://"+ endpoints.getHealthCheckURL(),String.class);
                    if(response!=null){
                        statusCode = response.getStatusCodeValue();
                        if(statusCode >= 200 && statusCode <=299){ // healthcheckURL hit is success
                            endpoints.setStatus("UP");
                            System.out.println("HealthcheckURL hit Success with code " + "(" + statusCode +")");
                        }
                        else if(statusCode >= 300 && statusCode <= 399){ // heatlhcheckURL hit is redirected
                            endpoints.setStatus("DOWN");
                            System.out.println("HealthCheckURL hit Failure with code" + "(" + statusCode +")");
                        }
                        else if(statusCode >= 400 && statusCode <=499){ // healthcheckURL hit faced Client Error
                            endpoints.setStatus("DOWN");
                            System.out.println("HealthCheckURL hit Failure with code" + "(" + statusCode +")");
                        }
                        else if(statusCode >= 500 && statusCode <= 599){ // healthcheckURL hit faced Server Error
                            endpoints.setStatus("DOWN");
                            System.out.println("HealthCheckURL hit Failure with code"  + "(" + statusCode +")");
                        }
                    }
                    else { //response is null because URL not reachable or unactive
                        endpoints.setStatus("DOWN");
                        statusCode = response.getStatusCodeValue();
                        System.out.println("HealthCheckURL hit Failure with code" + "(null response)");
                    }
                }
                catch (Exception e){ //Unable to get Response Entity
                    endpoints.setStatus("DOWN");
                    System.out.println("HealthCheckURL hit Failure with code " + "(unknown host)");
                }
            }
            t.commit();
            s.close();
            return endpointsList;
        }
        catch (Exception e)
        {
            System.out.println("Error getting HealthCheckURLs from Database");
            return null;
        }
    }

    @Override
    public List<ServiceEndpoints> EndpointCheck() {
        try {

            Configuration config = new Configuration().configure("persistence-cfg.xml").addAnnotatedClass(ServiceEndpoints.class);
            SessionFactory sf = config.buildSessionFactory();
            Session s = sf.openSession();
            Transaction t = s.beginTransaction();
            Query query = s.createQuery("from ServiceEndpoints");
            List<ServiceEndpoints> endpointsList = query.list();
            for(ServiceEndpoints endpoints : endpointsList){
                RestTemplate restTemplate = new RestTemplate();
                int statusCode = 0;
                try {
                    ResponseEntity<String> response = restTemplate.getForEntity( "http://"+ endpoints.getServiceEndpointURL(),String.class);
                    if(response!=null){
                        statusCode = response.getStatusCodeValue();
                        if(statusCode >= 200 && statusCode <=299){ // endpointURL hit is success
                            endpoints.setStatus("UP");
                            System.out.println("endpointURL hit Success with code " + "(" + statusCode +")");
                        }
                        else if(statusCode >= 300 && statusCode <= 399){ // endpointURL hit is redirected
                            endpoints.setStatus("UP");
                            System.out.println("endpointURL hit Success with code" + "(" + statusCode +")");
                        }
                        else if(statusCode >= 400 && statusCode <=499){ // endpointURL hit faced Client Error
                            endpoints.setStatus("DOWN");
                            System.out.println("endpointURL hit Failure with code" + "(" + statusCode +")");
                        }
                        else if(statusCode >= 500 && statusCode <= 599){ // endpointURL hit faced Server Error
                            endpoints.setStatus("DOWN");
                            System.out.println("endpointURL hit Failure with code"  + "(" + statusCode +")");
                        }
                    }
                    else { //response is null URL not reachable or active
                        endpoints.setStatus("DOWN");
                        statusCode = response.getStatusCodeValue();
                        System.out.println("endpointURL hit Failure with code" + "(null response)");
                    }
                }
                catch (Exception e){ //Unable to get Response Entity
                    endpoints.setStatus("DOWN");
                    System.out.println("endpointURL hit Failure with code " + "(unknown host)");
                }
            }
            t.commit();
            s.close();
            return endpointsList;
        }
        catch (Exception e)
        {
            System.out.println("Error getting HealthCheckURLs from Database");
            return null;
        }
    }

    @Override
    public List<ServiceEndpoints> PingCheck() {
        try {

            Configuration config = new Configuration().configure("persistence-cfg.xml").addAnnotatedClass(ServiceEndpoints.class);
            SessionFactory sf = config.buildSessionFactory();
            Session s = sf.openSession();
            Transaction t = s.beginTransaction();
            Query query = s.createQuery("from ServiceEndpoints");
            List<ServiceEndpoints> endpointsList = query.list();
            for(ServiceEndpoints endpoints : endpointsList){
                int responseCode = 0;
                InetAddress address;
                try {
                    Socket socket = new Socket(endpoints.getServiceEndpointURL(),80);
                    address = socket.getInetAddress();
                    if(address != null && address.isReachable(1000)) {
                        System.out.println("Ping Success for " + address);
                        endpoints.setStatus("UP");
                    }
                    else
                        endpoints.setStatus("DOWN");
                    socket.close();
                }
                catch (java.io.IOException e){
                        System.out.println("Ping Failed for " +endpoints.getServiceEndpointURL()); //Connection Failure
                }
            }
            t.commit();
            s.close();
            return endpointsList;
        }
        catch (Exception e)
        {
            System.out.println("Error getting HealthCheckURLs from Database");
            return null;
        }
    }


}

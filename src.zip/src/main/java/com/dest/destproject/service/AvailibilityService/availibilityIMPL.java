package com.dest.destproject.service.AvailibilityService;

import com.dest.destproject.entity.EndpointsAvailibility.EndpointsAvailibility;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class availibilityIMPL implements availibilityDAO{

    @Override
    public List<EndpointsAvailibility> getAvailibility() {

        try {

            Configuration config = new Configuration().configure("persistence-cfg.xml").addAnnotatedClass(EndpointsAvailibility.class);
            SessionFactory sf = config.buildSessionFactory();
            Session s = sf.openSession();
            Transaction t = s.beginTransaction();
            Query query = s.createQuery("from EndpointsAvailibility");
            List<EndpointsAvailibility> endpointsList = query.list();
            t.commit();
            s.close();
            return endpointsList;
        }
        catch (Exception e)
        {
            System.out.println("Error Connecting to Database");
            return null;
        }
    }
}

package com.dest.destproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import com.dest.destproject.entity.EndpointsAvailibility.EndpointsAvailibility;
import com.dest.destproject.service.EndpointService.endpointDAO;
import com.dest.destproject.service.AvailibilityService.availibilityDAO;
import com.dest.destproject.service.HealthService.HealthServiceDAO;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/dashboard")
public class AppController {

    @Autowired
    endpointDAO endDAO;

    @Autowired
    availibilityDAO availibilityDAO;

    @Autowired
    HealthServiceDAO healthServiceDAO;

    @GetMapping(value = "/endpoints/{option}",produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<ServiceEndpoints> getallEndpoints(@PathVariable int option){
        List<ServiceEndpoints> endpointsList = endDAO.getEndpoints();
        if(option == 1){
            List<ServiceEndpoints> healthcheckurls = healthServiceDAO.HealthCheck();
            return healthcheckurls;
        }
        else if (option ==  2){
            List<ServiceEndpoints> endpointcheckurls = healthServiceDAO.EndpointCheck();
            return  endpointcheckurls;
        }
        else if (option == 3){
            List<ServiceEndpoints> pingcheckurls = healthServiceDAO.PingCheck();
            return pingcheckurls;
        }
        else
            return null;
    }

    @GetMapping(value = "/availibility",produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<EndpointsAvailibility> getallAvailibility(){
        List<EndpointsAvailibility> endpointsAvailibilityList = availibilityDAO.getAvailibility();
        return endpointsAvailibilityList;
    }

}

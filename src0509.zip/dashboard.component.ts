import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Endpoints} from '../model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  active = 1;
  rowData : Endpoints[]= [];
  activeData : Endpoints[]= [];
  inactiveData : Endpoints[]= [];
  teams: any[]=[];

  public activePillIndex:number = 0;

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.healthcheck();
  }

  columnDefs = [
    {headerName: 'id', field: 'id'},
    {headerName: 'status', field: 'status'},
    {headerName: 'application', field: 'application'},
    {headerName: 'contact', field: 'contac'},
    {headerName: 'healthCheckURL', field: 'healthCheckURL'},
    {headerName: 'modifiedDate', field: 'modifiedDate'},
    {headerName: 'modifiedBy', field: 'modifiedBy'},
    {headerName: 'createdDate', field: 'createdDate'},
    {headerName: 'createdBy', field: 'createdBy'},
    {headerName: 'availibility', field: 'availibility'},
    {headerName: 'serviceEndpointURL', field: 'serviceEndpointURL'},
    {headerName: 'serviceKey', field: 'serviceKey'}
  ];

  healthcheck(){
    let response = this.http.get<Endpoints[]>("http://localhost:8080/dashboard/healthService/availabilityEndpoints");
    response.subscribe((data : Endpoints[])=>{
      for(let i=0;i<data.length;i++){
        if(data[i].status=='UP'){
          this.activeData.push(data[i]);
        }
        else if(data[i].status=='DOWN'){
          this.inactiveData.push(data[i]);
        }
      }

      for(let i=0;i<data.length;i++){
        if(!this.teams.includes(data[i].contact)){
          this.teams.push(data[i].contact);
        }
      }

      console.log(this.teams);
      console.log(this.activeData);
      console.log(this.inactiveData);
    });
  }

  public selectPill(index:number) {
    this.activePillIndex = index;
}
}

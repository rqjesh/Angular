package com.dest.destproject.controller;

import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.dest.destproject.service.CrudService.ServiceEndpointCrudIMPL;

import java.util.List;

@RestController
@RequestMapping("/dashboard/endpointService")
public class ServiceEndpointController {

    @Autowired
    private ServiceEndpointCrudIMPL service;

    @PostMapping(value = "/addEndpoint",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ServiceEndpoints addEndpoint(@RequestBody ServiceEndpoints endpoints){

        return service.saveServiceEndpoint(endpoints);
    }

    @PostMapping(value = "/addEndpoints",consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<ServiceEndpoints> addEndpoints(@RequestBody List<ServiceEndpoints> endpointsList){

        return service.saveServiceEndpoints(endpointsList);
    }

    @GetMapping("/getEndpoints")
    public List<ServiceEndpoints> findAllEndpoints(){

        return service.getServiceEndpoints();
    }

    @GetMapping("/endpointsById/{id}")
    public ServiceEndpoints findEndpointById(@PathVariable(value = "id") int id){

        return service.getServiceEndpointbyId(id);
    }

    @GetMapping("/endpointsByKey/{key}")
    public ServiceEndpoints findEndpointByKey(@PathVariable(value = "key") String key){

        return service.getServiceEndpointbyKey(key);
    }

    @PutMapping(value = "/update",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ServiceEndpoints updateEndpoint(@RequestBody ServiceEndpoints endpoints){

        return service.updateServiceEndpoint(endpoints);
    }

    @PutMapping(value = "/updateList",consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<ServiceEndpoints> updateEndpointList(@RequestBody List<ServiceEndpoints> endpointsList){

        return service.updateServiceEndpoints(endpointsList);
    }

    @DeleteMapping("/deleteById/{id}")
    public String deleteEndpoint(@PathVariable int id){

        return service.deleteServiceEndpointbyId(id);
    }

    @DeleteMapping("/deleteByKey/{key}")
    public String deleteEndpoint(@PathVariable String key){

        return  service.deleteServiceEndpointbyKey(key);
    }
}

package com.dest.destproject.controller;

import com.dest.destproject.entity.EndpointsAvailability.EndpointsAvailability;
import com.dest.destproject.service.CrudService.EndpointAvailabilityCrudIMPL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/dashboard/availabilityService")
public class EndpointAvailabilityController {

    @Autowired
    EndpointAvailabilityCrudIMPL service;

    @PostMapping(value = "/addEndpoint",consumes = MediaType.APPLICATION_JSON_VALUE)
    public EndpointsAvailability addEndpoint(@RequestBody EndpointsAvailability endpoints){

        return service.saveAvailabilityEndpoint(endpoints);
    }

    @PostMapping(value = "/addEndpoints",consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<EndpointsAvailability> addEndpoints(@RequestBody List<EndpointsAvailability> endpointsList){

        return service.saveAvailabilityEndpoints(endpointsList);
    }

    @GetMapping("/getEndpoints")
    public List<EndpointsAvailability> findAllEndpoints(){

        return service.getAvailabilityEndpoints();
    }

    @GetMapping("/endpointsById/{id}")
    public EndpointsAvailability findEndpointById(@PathVariable(value = "id") int id){

        return service.getAvailabilityEndpointbyId(id);
    }

    @GetMapping("/endpointsByKey/{key}")
    public EndpointsAvailability findEndpointByKey(@PathVariable(value = "key") String key){

        return service.getAvailabilityEndpointbyKey(key);
    }

    @PutMapping(value = "/update",consumes = MediaType.APPLICATION_JSON_VALUE)
    public EndpointsAvailability updateEndpoint(@RequestBody EndpointsAvailability endpoints){

        return service.updateAvailabilityEndpoint(endpoints);
    }

    @PutMapping(value = "/updateList",consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<EndpointsAvailability> updateEndpointList(@RequestBody List<EndpointsAvailability> endpointsList){

        return service.updateAvailabilityEndpoints(endpointsList);
    }

    @DeleteMapping("/deleteById/{id}")
    public String deleteEndpoint(@PathVariable int id){

        return service.deleteAvailabilityEndpointbyId(id);
    }

    @DeleteMapping("/deleteByKey/{key}")
    public String deleteEndpoint(@PathVariable String key){

        return  service.deleteAvailabilityEndpointbyKey(key);
    }
}

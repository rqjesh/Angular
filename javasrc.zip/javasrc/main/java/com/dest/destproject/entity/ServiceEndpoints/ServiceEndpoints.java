package com.dest.destproject.entity.ServiceEndpoints;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity(name = "DEST_SERVICE_ENDPOINTS")
@XmlRootElement
@Table(name = "DEST_SERVICE_ENDPOINTS")
public class ServiceEndpoints {

    @Id
    @Column(name = "ID")
    private int Id;
    @Column(name = "APPLICATION")
    private String application;
    @Column(name = "SERVICE_KEY")
    private String serviceKey;
    @Column(name = "SERVICE_ENDPOINT_URL")
    private String serviceEndpointURL;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "CREATED_DATE")
    private String createdDate;
    @Column(name = "MODIFIED_BY")
    private String modifiedBy;
    @Column(name = "MODIFIED_DATE")
    private String modifiedDate;
    @Column(name = "CONTACT")
    private String contact;
    @Column(name = "HEALTH_CHECK_URL")
    private String healthCheckURL;
    @Column(name = "STATUS")
    private String status;


    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getServiceKey() {
        return serviceKey;
    }

    public void setServiceKey(String serviceKey) {
        this.serviceKey = serviceKey;
    }

    public String getServiceEndpointURL() {
        return serviceEndpointURL;
    }

    public void setServiceEndpointURL(String serviceEndpointURL) {
        this.serviceEndpointURL = serviceEndpointURL;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getHealthCheckURL() {
        return healthCheckURL;
    }

    public void setHealthCheckURL(String healthCheckURL) {
        this.healthCheckURL = healthCheckURL;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ServiceEndpoints(int id,String application, String serviceKey, String serviceEndpointURL, String createdBy, String createdDate, String modifiedBy, String modifiedDate, String contact, String healthCheckURL, String status) {
        Id = id;
        this.application = application;
        this.serviceKey = serviceKey;
        this.serviceEndpointURL = serviceEndpointURL;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
        this.contact = contact;
        this.healthCheckURL = healthCheckURL;
        this.status = status;
    }

    public ServiceEndpoints() {
        super();
    }

    @Override
    public String toString() {
        return "ServiceEndpoints{" +
                "Id=" + Id +
                ", application='" + application + '\'' +
                ", serviceKey='" + serviceKey + '\'' +
                ", serviceEndpointURL='" + serviceEndpointURL + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", modifiedBy='" + modifiedBy + '\'' +
                ", modifiedDate='" + modifiedDate + '\'' +
                ", contact='" + contact + '\'' +
                ", healthCheckURL='" + healthCheckURL + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}

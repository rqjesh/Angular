package com.dest.destproject.service.HealthService;

import com.dest.destproject.entity.EndpointsAvailability.EndpointsAvailability;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface HealthServiceDAO {

    //Remove comments if you need other options

 //   public List<ServiceEndpoints> HealthCheck();
//    public List<ServiceEndpoints> EndpointCheck();
    public List<ServiceEndpoints> PingCheck();

    public List<EndpointsAvailability> refreshHealthCheck() throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException;
 //   public List<EndpointsAvailability> refreshEndpointCheck();
  //  public List<EndpointsAvailability> refreshPingCheck();
}

package com.dest.destproject.service.CrudService;

import com.dest.destproject.entity.EndpointsAvailability.EndpointsAvailability;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EndpointAvailabilityCrudDAO extends JpaRepository<EndpointsAvailability,Integer> {

    @Query("from DEST_SERVICE_ENDPOINTS_AVAILIBILITY where serviceKey=?1")
    public EndpointsAvailability findByKey(String serviceKey);
    @Query("from DEST_SERVICE_ENDPOINTS_AVAILIBILITY where serviceKey=?1")
    public EndpointsAvailability deleteByKey(String serviceKey);
}

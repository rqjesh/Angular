package com.dest.destproject.service.CrudService;

import com.dest.destproject.entity.EndpointsAvailability.EndpointsAvailability;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EndpointAvailabilityCrudIMPL {

    @Autowired
    private EndpointAvailabilityCrudDAO availabilityRepository;

    public EndpointsAvailability saveAvailabilityEndpoint(EndpointsAvailability endpoint){ // Insert data one by one

        return availabilityRepository.save(endpoint);
    }

    public List<EndpointsAvailability> saveAvailabilityEndpoints(List<EndpointsAvailability> endpoints){ // Insert data by providing a list

        return availabilityRepository.saveAll(endpoints);
    }

    public List<EndpointsAvailability> getAvailabilityEndpoints(){

        return availabilityRepository.findAll();
    }

    public EndpointsAvailability getAvailabilityEndpointbyId(int Id){

        return availabilityRepository.findById(Id).orElse(null);
    }

    public EndpointsAvailability getAvailabilityEndpointbyKey(String Key){

        return availabilityRepository.findByKey(Key);
    }

    public String deleteAvailabilityEndpointbyId(int Id){

        availabilityRepository.deleteById(Id);
        return "data removed !! " + Id;
    }

    public String deleteAvailabilityEndpointbyKey(String key){
        availabilityRepository.deleteByKey(key);
        return "data with Key " +key+" removed";
    }

    public EndpointsAvailability updateAvailabilityEndpoint(EndpointsAvailability endpoints){

        EndpointsAvailability existingendpoint = availabilityRepository.findById(endpoints.getId()).orElse(null);

        existingendpoint.setId(endpoints.getId());
        existingendpoint.setApplication(endpoints.getApplication());
        existingendpoint.setCreatedBy(endpoints.getCreatedBy());
        existingendpoint.setCreatedDate(endpoints.getCreatedDate());
        existingendpoint.setModifiedBy(endpoints.getModifiedBy());
        existingendpoint.setModifiedDate(endpoints.getModifiedDate());
        existingendpoint.setServiceEndpointURL(endpoints.getServiceEndpointURL());
        existingendpoint.setServiceKey(endpoints.getServiceKey());
        existingendpoint.setAvailability(endpoints.getAvailability());
        existingendpoint.setStatus(endpoints.getStatus());

        return availabilityRepository.save(existingendpoint);
    }

    public List<EndpointsAvailability>  updateAvailabilityEndpoints(List<EndpointsAvailability> endpointsList){

        for(EndpointsAvailability newlist : endpointsList){

            EndpointsAvailability existingendpoint = availabilityRepository.findById(newlist.getId()).orElse(null);

            existingendpoint.setId(newlist.getId());
            existingendpoint.setApplication(newlist.getApplication());
            existingendpoint.setCreatedBy(newlist.getCreatedBy());
            existingendpoint.setCreatedDate(newlist.getCreatedDate());
            existingendpoint.setModifiedBy(newlist.getModifiedBy());
            existingendpoint.setModifiedDate(newlist.getModifiedDate());
            existingendpoint.setServiceEndpointURL(newlist.getServiceEndpointURL());
            existingendpoint.setServiceKey(newlist.getServiceKey());
            existingendpoint.setAvailability(newlist.getAvailability());
            existingendpoint.setStatus(newlist.getStatus());
        }

        return availabilityRepository.saveAll(endpointsList);
    }
}

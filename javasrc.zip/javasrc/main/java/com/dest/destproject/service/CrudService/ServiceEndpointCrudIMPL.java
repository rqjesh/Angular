package com.dest.destproject.service.CrudService;

import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServiceEndpointCrudIMPL {

    @Autowired
    private ServiceEndpointCrudDAO endpointsRepository;

    public ServiceEndpoints saveServiceEndpoint(ServiceEndpoints endpoint){ // Insert data one by one

        return endpointsRepository.save(endpoint);
    }

    public List<ServiceEndpoints> saveServiceEndpoints(List<ServiceEndpoints> endpoints){ // Insert data by providing a list

        return endpointsRepository.saveAll(endpoints);
    }

    public List<ServiceEndpoints> getServiceEndpoints(){

        return endpointsRepository.findAll();
    }

    public ServiceEndpoints getServiceEndpointbyId(int Id){

        return endpointsRepository.findById(Id).orElse(null);
    }

    public ServiceEndpoints getServiceEndpointbyKey(String Key){

        return endpointsRepository.findByKey(Key);
    }

    public String deleteServiceEndpointbyId(int Id){

        endpointsRepository.deleteById(Id);
        return "data removed !! " + Id;
    }

    public String deleteServiceEndpointbyKey(String key){
        endpointsRepository.deleteByKey(key);
        return "data with Key " +key+" removed";
    }

    public ServiceEndpoints updateServiceEndpoint(ServiceEndpoints endpoints){

        ServiceEndpoints existingendpoint = endpointsRepository.findById(endpoints.getId()).orElse(null);

        existingendpoint.setId(endpoints.getId());
        existingendpoint.setApplication(endpoints.getApplication());
        existingendpoint.setContact(endpoints.getContact());
        existingendpoint.setCreatedBy(endpoints.getCreatedBy());
        existingendpoint.setCreatedDate(endpoints.getCreatedDate());
        existingendpoint.setHealthCheckURL(endpoints.getHealthCheckURL());
        existingendpoint.setModifiedBy(endpoints.getModifiedBy());
        existingendpoint.setModifiedDate(endpoints.getModifiedDate());
        existingendpoint.setServiceEndpointURL(endpoints.getServiceEndpointURL());
        existingendpoint.setServiceKey(endpoints.getServiceKey());
        existingendpoint.setStatus(endpoints.getStatus());

        return endpointsRepository.save(existingendpoint);
    }

    public List<ServiceEndpoints>  updateServiceEndpoints(List<ServiceEndpoints> endpointsList){

        for(ServiceEndpoints newlist : endpointsList){

            ServiceEndpoints existingendpoint = endpointsRepository.findById(newlist.getId()).orElse(null);

            existingendpoint.setId(newlist.getId());
            existingendpoint.setApplication(newlist.getApplication());
            existingendpoint.setContact(newlist.getContact());
            existingendpoint.setCreatedBy(newlist.getCreatedBy());
            existingendpoint.setCreatedDate(newlist.getCreatedDate());
            existingendpoint.setHealthCheckURL(newlist.getHealthCheckURL());
            existingendpoint.setModifiedBy(newlist.getModifiedBy());
            existingendpoint.setModifiedDate(newlist.getModifiedDate());
            existingendpoint.setServiceEndpointURL(newlist.getServiceEndpointURL());
            existingendpoint.setServiceKey(newlist.getServiceKey());
            existingendpoint.setStatus(newlist.getStatus());
        }

        return endpointsRepository.saveAll(endpointsList);
    }

}

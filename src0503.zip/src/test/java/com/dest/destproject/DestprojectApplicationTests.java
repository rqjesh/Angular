package com.dest.destproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DestprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}

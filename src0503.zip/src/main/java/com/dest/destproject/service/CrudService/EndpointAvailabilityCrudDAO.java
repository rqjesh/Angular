package com.dest.destproject.service.CrudService;

import com.dest.destproject.entity.EndpointsAvailibility.EndpointsAvailibility;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EndpointAvailabilityCrudDAO extends JpaRepository<EndpointsAvailibility,Integer> {

    @Query("from DEST_SERVICE_ENDPOINTS_AVAILIBILITY where serviceKey=?1")
    public EndpointsAvailibility findByKey(String serviceKey);
    @Query("from DEST_SERVICE_ENDPOINTS_AVAILIBILITY where serviceKey=?1")
    public EndpointsAvailibility deleteByKey(String serviceKey);
}

package com.dest.destproject.service.CrudService;

import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceEndpointCrudDAO extends JpaRepository<ServiceEndpoints,Integer> {

    @Query("from DEST_SERVICE_ENDPOINTS where serviceKey=?1")
    public ServiceEndpoints findByKey(String serviceKey);
    @Query("from DEST_SERVICE_ENDPOINTS where serviceKey=?1")
    public ServiceEndpoints deleteByKey(String serviceKey);
}

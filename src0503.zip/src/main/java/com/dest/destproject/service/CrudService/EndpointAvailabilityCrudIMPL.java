package com.dest.destproject.service.CrudService;

import com.dest.destproject.entity.EndpointsAvailibility.EndpointsAvailibility;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EndpointAvailabilityCrudIMPL {

    @Autowired
    private EndpointAvailabilityCrudDAO availabilityRepository;

    public EndpointsAvailibility saveAvailabilityEndpoint(EndpointsAvailibility endpoint){ // Insert data one by one

        return availabilityRepository.save(endpoint);
    }

    public List<EndpointsAvailibility> saveAvailabilityEndpoints(List<EndpointsAvailibility> endpoints){ // Insert data by providing a list

        return availabilityRepository.saveAll(endpoints);
    }

    public List<EndpointsAvailibility> getAvailabilityEndpoints(){

        return availabilityRepository.findAll();
    }

    public EndpointsAvailibility getAvailabilityEndpointbyId(int Id){

        return availabilityRepository.findById(Id).orElse(null);
    }

    public EndpointsAvailibility getAvailabilityEndpointbyKey(String Key){

        return availabilityRepository.findByKey(Key);
    }

    public String deleteAvailabilityEndpointbyId(int Id){

        availabilityRepository.deleteById(Id);
        return "data removed !! " + Id;
    }

    public String deleteAvailabilityEndpointbyKey(String key){
        availabilityRepository.deleteByKey(key);
        return "data with Key " +key+" removed";
    }

    public EndpointsAvailibility updateAvailabilityEndpoint(EndpointsAvailibility endpoints){

        EndpointsAvailibility existingendpoint = availabilityRepository.findById(endpoints.getId()).orElse(null);

        existingendpoint.setId(endpoints.getId());
        existingendpoint.setCreatedBy(endpoints.getCreatedBy());
        existingendpoint.setCreatedDate(endpoints.getCreatedDate());
        existingendpoint.setModifiedBy(endpoints.getModifiedBy());
        existingendpoint.setModifiedDate(endpoints.getModifiedDate());
        existingendpoint.setServiceEndpointURL(endpoints.getServiceEndpointURL());
        existingendpoint.setServiceKey(endpoints.getServiceKey());

        return availabilityRepository.save(existingendpoint);
    }

    public List<EndpointsAvailibility>  updateAvailabilityEndpoints(List<EndpointsAvailibility> endpointsList){

        for(EndpointsAvailibility newlist : endpointsList){

            EndpointsAvailibility existingendpoint = availabilityRepository.findById(newlist.getId()).orElse(null);

            existingendpoint.setId(newlist.getId());
            existingendpoint.setCreatedBy(newlist.getCreatedBy());
            existingendpoint.setCreatedDate(newlist.getCreatedDate());
            existingendpoint.setModifiedBy(newlist.getModifiedBy());
            existingendpoint.setModifiedDate(newlist.getModifiedDate());
            existingendpoint.setServiceEndpointURL(newlist.getServiceEndpointURL());
            existingendpoint.setServiceKey(newlist.getServiceKey());
        }

        return availabilityRepository.saveAll(endpointsList);
    }
}

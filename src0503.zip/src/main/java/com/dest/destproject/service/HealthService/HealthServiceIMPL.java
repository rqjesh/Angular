package com.dest.destproject.service.HealthService;

import com.dest.destproject.entity.EndpointsAvailibility.EndpointsAvailibility;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.dest.destproject.service.CrudService.ServiceEndpointCrudIMPL;
import com.dest.destproject.service.CrudService.EndpointAvailabilityCrudIMPL;

import java.net.HttpURLConnection;
import java.net.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

@Service
public class HealthServiceIMPL implements HealthServiceDAO {

    @Autowired
    ServiceEndpointCrudIMPL serviceDAO;
    @Autowired
    EndpointAvailabilityCrudIMPL endDAO;

    // Has to run for the first time everyday at 12.00 and update data on 1st table

    @Scheduled(cron="0 0 0 * * ?")
    public List<ServiceEndpoints> HealthCheck() {

        try {

            //Implement the functionality where we have to import data from excel and get it in List type


            List<ServiceEndpoints> endpointsList = serviceDAO.getServiceEndpoints();
            this.checkhealth(endpointsList);
            serviceDAO.saveServiceEndpoints(endpointsList);
            return endpointsList;
        } catch (Exception e) {
            System.out.println("Error getting/setting HealthCheckURLs from/to Repository");
            return null;
        }
    }

    @Scheduled(cron="0 0 0 * * ?")
    public List<ServiceEndpoints> EndpointCheck() {

        try {

            //Implement the functionality where we have to import data from excel and get it in List type


            List<ServiceEndpoints> endpointsList = serviceDAO.getServiceEndpoints();
            this.checkendpoints(endpointsList);
            serviceDAO.saveServiceEndpoints(endpointsList);
            return endpointsList;
        } catch (Exception e) {
            System.out.println("Error getting/setting EndpointCheckURLs from/to Repository");
            return null;
        }
    }

    @Scheduled(cron="0 0 0 * * ?")
    public List<ServiceEndpoints> PingCheck() {

        try {

            //Implement the functionality where we have to import data from excel and get it in List type


            List<ServiceEndpoints> endpointsList = serviceDAO.getServiceEndpoints();
            this.checkping(endpointsList);
            serviceDAO.saveServiceEndpoints(endpointsList);
            return endpointsList;
        } catch (Exception e) {
            System.out.println("Error getting/setting EndpointCheckURLs from/to Repository");
            return null;
        }
    }

    //Helper methods for 1st table URL checks


    public List<ServiceEndpoints> checkhealth(List<ServiceEndpoints> endpointsList) {

        for (ServiceEndpoints endpoints : endpointsList) {
            RestTemplate restTemplate = new RestTemplate();
            int statusCode = 0;
            try {
                ResponseEntity<String> response = restTemplate.getForEntity("http://" + endpoints.getHealthCheckURL(), String.class);
                if (response != null) {
                    statusCode = response.getStatusCodeValue();
                    if (statusCode >= 200 && statusCode <= 299) { // healthcheckURL hit is success
                        endpoints.setStatus("UP");
                        System.out.println("HealthcheckURL hit Success with code " + "(" + statusCode + ")");
                    } else if (statusCode >= 300 && statusCode <= 399) { // heatlhcheckURL hit is redirected
                        endpoints.setStatus("DOWN");
                        System.out.println("HealthCheckURL hit Failure with code" + "(" + statusCode + ")");
                    } else if (statusCode >= 400 && statusCode <= 499) { // healthcheckURL hit faced Client Error
                        endpoints.setStatus("DOWN");
                        System.out.println("HealthCheckURL hit Failure with code" + "(" + statusCode + ")");
                    } else if (statusCode >= 500 && statusCode <= 599) { // healthcheckURL hit faced Server Error
                        endpoints.setStatus("DOWN");
                        System.out.println("HealthCheckURL hit Failure with code" + "(" + statusCode + ")");
                    }
                } else { //response is null because URL not reachable or unactive
                    endpoints.setStatus("DOWN");
                    statusCode = response.getStatusCodeValue();
                    System.out.println("HealthCheckURL hit Failure with code" + "(null response)");
                }
            } catch (Exception e) { //Unable to get Response Entity
                endpoints.setStatus("DOWN");
                System.out.println("HealthCheckURL hit Failure with code " + "(unknown host)");
            }
        }
        return endpointsList;
    }

    public List<ServiceEndpoints> checkendpoints(List<ServiceEndpoints> endpointsList) {

        for (ServiceEndpoints endpoints : endpointsList) {
            RestTemplate restTemplate = new RestTemplate();
            int statusCode = 0;
            try {
                ResponseEntity<String> response = restTemplate.getForEntity("http://" + endpoints.getServiceEndpointURL(), String.class);
                if (response != null) {
                    statusCode = response.getStatusCodeValue();
                    if (statusCode >= 200 && statusCode <= 299) { // endpointURL hit is success
                        endpoints.setStatus("UP");
                        System.out.println("endpointURL hit Success with code " + "(" + statusCode + ")");
                    } else if (statusCode >= 300 && statusCode <= 399) { // endpointURL hit is redirected
                        endpoints.setStatus("UP");
                        System.out.println("endpointURL hit Success with code" + "(" + statusCode + ")");
                    } else if (statusCode >= 400 && statusCode <= 499) { // endpointURL hit faced Client Error
                        endpoints.setStatus("DOWN");
                        System.out.println("endpointURL hit Failure with code" + "(" + statusCode + ")");
                    } else if (statusCode >= 500 && statusCode <= 599) { // endpointURL hit faced Server Error
                        endpoints.setStatus("DOWN");
                        System.out.println("endpointURL hit Failure with code" + "(" + statusCode + ")");
                    }
                } else { //response is null URL not reachable or active
                    endpoints.setStatus("DOWN");
                    statusCode = response.getStatusCodeValue();
                    System.out.println("endpointURL hit Failure with code" + "(null response)");
                }
            } catch (Exception e) { //Unable to get Response Entity
                endpoints.setStatus("DOWN");
                System.out.println("endpointURL hit Failure with code " + "(unknown host)");
            }
        }
        return endpointsList;
    }


    public List<ServiceEndpoints> checkping(List<ServiceEndpoints> endpointsList) {

        for (ServiceEndpoints endpoints : endpointsList) {
            int responseCode = 0;
            InetAddress address;
            try {
                Socket socket = new Socket(endpoints.getServiceEndpointURL(), 80);
                address = socket.getInetAddress();
                if (address != null && address.isReachable(1000)) {
                    System.out.println("Ping Success for " + address);
                    endpoints.setStatus("UP");
                } else
                    endpoints.setStatus("DOWN");
                socket.close();
            } catch (java.io.IOException e) {
                System.out.println("Ping Failed for " + endpoints.getServiceEndpointURL()); //Connection Failure
            }
        }
        return endpointsList;
    }


    //Take data from 1st table and refresh every 15mins and simultaneously update in 2nd table

    // comment as it is optional way
 /*   @Scheduled(fixedDelayString = "PT015M")
    public List<EndpointsAvailibility> refreshHealthCheck() {

        List<ServiceEndpoints> endpointsList = serviceDAO.getServiceEndpoints();
        List<EndpointsAvailibility> availibilityList = endDAO.getAvailabilityEndpoints();
        EndpointsAvailibility availibility = new EndpointsAvailibility();

        for (ServiceEndpoints se : endpointsList) {
            availibility.setId(se.getId());
            availibility.setCreatedDate(se.getCreatedDate());
            availibility.setCreatedBy(se.getCreatedBy());
            availibility.setModifiedDate(se.getModifiedDate());
            availibility.setModifiedBy(se.getModifiedBy());
            availibility.setServiceEndpointURL(se.getServiceEndpointURL());
            availibility.setServiceKey(se.getServiceKey());
            availibility.setContact(se.getContact());
            availibility.setHealthCheckURL(se.getHealthCheckURL());

            RestTemplate restTemplate = new RestTemplate();
            int statusCode = 0;

            try {
                ResponseEntity<String> response = restTemplate.getForEntity("http://" + se.getHealthCheckURL(), String.class);
                if (response != null) {
                    statusCode = response.getStatusCodeValue();
                    if (statusCode >= 200 && statusCode <= 299) { // healthcheckURL hit is success
                        availibility.setAvailibility("YES");
                        System.out.println("HealthcheckURL hit Success with code " + "(" + statusCode + ")");
                    } else if (statusCode >= 300 && statusCode <= 399) { // heatlhcheckURL hit is redirected
                        availibility.setAvailibility("NO");
                        System.out.println("HealthCheckURL hit Failure with code" + "(" + statusCode + ")");
                    } else if (statusCode >= 400 && statusCode <= 499) { // healthcheckURL hit faced Client Error
                        availibility.setAvailibility("NO");
                        System.out.println("HealthCheckURL hit Failure with code" + "(" + statusCode + ")");
                    } else if (statusCode >= 500 && statusCode <= 599) { // healthcheckURL hit faced Server Error
                        availibility.setAvailibility("NO");
                        System.out.println("HealthCheckURL hit Failure with code" + "(" + statusCode + ")");
                    }
                } else { //response is null because URL not reachable or unactive
                    availibility.setAvailibility("NO");
                    statusCode = response.getStatusCodeValue();
                    System.out.println("HealthCheckURL hit Failure with code" + "(null response)");
                }
            } catch (Exception e) {
                availibility.setAvailibility("NO");
                System.out.println("HealthCheckURL hit Failure with code " + "(unknown host)");
            }
            endDAO.saveAvailabilityEndpoint(availibility);
        }
        return availibilityList;
    } */

    //commented as it is optional way
 /*   @Scheduled(fixedDelayString = "PT015M")
    public List<EndpointsAvailibility> refreshEndpointCheck() {

        List<ServiceEndpoints> endpointsList = serviceDAO.getServiceEndpoints();
        List<EndpointsAvailibility> availibilityList = endDAO.getAvailabilityEndpoints();
        EndpointsAvailibility availibility = new EndpointsAvailibility();

        for (ServiceEndpoints se : endpointsList) {
            availibility.setId(se.getId());
            availibility.setCreatedDate(se.getCreatedDate());
            availibility.setCreatedBy(se.getCreatedBy());
            availibility.setModifiedDate(se.getModifiedDate());
            availibility.setModifiedBy(se.getModifiedBy());
            availibility.setServiceEndpointURL(se.getServiceEndpointURL());
            availibility.setServiceKey(se.getServiceKey());
            availibility.setContact(se.getContact());
            availibility.setHealthCheckURL(se.getHealthCheckURL());

            RestTemplate restTemplate = new RestTemplate();
            int statusCode = 0;

            try {
                ResponseEntity<String> response = restTemplate.getForEntity("http://" + se.getServiceEndpointURL(), String.class);
                if (response != null) {
                    statusCode = response.getStatusCodeValue();
                    if (statusCode >= 200 && statusCode <= 299) { // healthcheckURL hit is success
                        availibility.setAvailibility("YES");
                        System.out.println("EndpointcheckURL hit Success with code " + "(" + statusCode + ")");
                    } else if (statusCode >= 300 && statusCode <= 399) { // heatlhcheckURL hit is redirected
                        availibility.setAvailibility("YES");
                        System.out.println("EndpointCheckURL hit Failure with code" + "(" + statusCode + ")");
                    } else if (statusCode >= 400 && statusCode <= 499) { // healthcheckURL hit faced Client Error
                        availibility.setAvailibility("NO");
                        System.out.println("EndpointCheckURL hit Failure with code" + "(" + statusCode + ")");
                    } else if (statusCode >= 500 && statusCode <= 599) { // healthcheckURL hit faced Server Error
                        availibility.setAvailibility("NO");
                        System.out.println("EndpointCheckURL hit Failure with code" + "(" + statusCode + ")");
                    }
                } else { //response is null because URL not reachable or unactive
                    availibility.setAvailibility("NO");
                    statusCode = response.getStatusCodeValue();
                    System.out.println("EndpointCheckURL hit Failure with code" + "(null response)");
                }
            } catch (Exception e) {
                availibility.setAvailibility("NO");
                System.out.println("EndpointCheckURL hit Failure with code " + "(unknown host)");
            }
            endDAO.saveAvailabilityEndpoint(availibility);
        }
        return availibilityList;
    } */

    @Scheduled(fixedDelayString = "PT015M")
    public List<EndpointsAvailibility> refreshPingCheck() {

        List<ServiceEndpoints> endpointsList = serviceDAO.getServiceEndpoints();
        List<EndpointsAvailibility> availibilityList = endDAO.getAvailabilityEndpoints();
        EndpointsAvailibility availibility = new EndpointsAvailibility();

        for (ServiceEndpoints se : endpointsList) {
            availibility.setId(se.getId());
            availibility.setCreatedDate(se.getCreatedDate());
            availibility.setCreatedBy(se.getCreatedBy());
            availibility.setModifiedDate(se.getModifiedDate());
            availibility.setModifiedBy(se.getModifiedBy());
            availibility.setServiceEndpointURL(se.getServiceEndpointURL());
            availibility.setServiceKey(se.getServiceKey());
            availibility.setContact(se.getContact());
            availibility.setHealthCheckURL(se.getHealthCheckURL());

            int responseCode = 0;
            InetAddress address;
            try {
                Socket socket = new Socket(se.getServiceEndpointURL(), 80);
                address = socket.getInetAddress();
                if (address != null && address.isReachable(1000)) {
                    System.out.println("Ping Success for " + address);
                    availibility.setAvailibility("YES");
                } else
                    availibility.setAvailibility("NO");
                socket.close();
            } catch (java.io.IOException e) {
                System.out.println("Ping Failed for " + availibility.getServiceEndpointURL());//Connection Failure
                availibility.setAvailibility("NO");
            }

            endDAO.saveAvailabilityEndpoint(availibility);

        }
        return availibilityList;
    }
}

package com.dest.destproject.service.HealthService;

import com.dest.destproject.entity.EndpointsAvailibility.EndpointsAvailibility;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.List;

public interface HealthServiceDAO {

    //Remove comments if you need other options

 //   public List<ServiceEndpoints> HealthCheck();
//    public List<ServiceEndpoints> EndpointCheck();
    public List<ServiceEndpoints> PingCheck();

 //   public List<EndpointsAvailibility> refreshHealthCheck();
 //   public List<EndpointsAvailibility> refreshEndpointCheck();
    public List<EndpointsAvailibility> refreshPingCheck();
}

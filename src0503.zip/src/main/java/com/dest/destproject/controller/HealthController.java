package com.dest.destproject.controller;

import com.dest.destproject.service.HealthService.HealthServiceIMPL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.dest.destproject.entity.ServiceEndpoints.ServiceEndpoints;
import com.dest.destproject.entity.EndpointsAvailibility.EndpointsAvailibility;
import com.dest.destproject.service.HealthService.HealthServiceDAO;
import com.dest.destproject.service.CrudService.ServiceEndpointCrudDAO;
import com.dest.destproject.service.CrudService.EndpointAvailabilityCrudDAO;
import com.dest.destproject.service.CrudService.ServiceEndpointCrudIMPL;
import com.dest.destproject.service.CrudService.EndpointAvailabilityCrudIMPL;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/dashboard/healthService")
public class HealthController {

    @Autowired
    HealthServiceDAO healthServiceDAO;
    @Autowired
    EndpointAvailabilityCrudDAO endpointAvailabilityCrudDAO;
    @Autowired
    ServiceEndpointCrudDAO serviceEndpointCrudDAO;
    @Autowired
    EndpointAvailabilityCrudIMPL endpointAvailabilityCrudIMPL;
    @Autowired
    ServiceEndpointCrudIMPL serviceEndpointCrudIMPL;

    @GetMapping(value = "/serviceEndpoints",produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<ServiceEndpoints> getallServiceEndpoints(){

        //Remove comments for multiple options and pass that as parameter to @GetMapping

    /*    if(option == 1){
            List<ServiceEndpoints> healthcheckurls = healthServiceDAO.HealthCheck();
            return healthcheckurls;
        }
        else if (option ==  2){
            List<ServiceEndpoints> endpointcheckurls = healthServiceDAO.EndpointCheck();
            return  endpointcheckurls;

     */
    //   else if (option == 3){
            List<ServiceEndpoints> pingcheckurls = serviceEndpointCrudIMPL.getServiceEndpoints();
            return pingcheckurls;
   //     }
    /*    else
            return null;
     */
    }

    @GetMapping(value = "/availabilityEndpoints",produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<EndpointsAvailibility> getallAvailableEndpoints(){

        //Remove comments for multiple options and pass that as parameter to @GetMapping

       /* if(option == 1){
            List<EndpointsAvailibility> healthcheckurls = healthServiceDAO.refreshHealthCheck();
            return healthcheckurls;
        }
        else if(option == 2){
            List<EndpointsAvailibility> endpointcheckurls = healthServiceDAO.refreshEndpointCheck();
            return endpointcheckurls;

        */
    //    else if(option == 3){
            List<EndpointsAvailibility> pingcheckurls = endpointAvailabilityCrudIMPL.getAvailabilityEndpoints();
            return  pingcheckurls;
    //    }
    /*    else
            return null;

     */
    }
}

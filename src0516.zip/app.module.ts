import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AgGridModule} from 'ag-grid-angular';
import { AppRoutingModule, ArrayOfComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbPaginationModule, NgbAlertModule, NgbAccordionModule,NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { ListComponent } from './list/list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AgGridComponent } from './ag-grid/ag-grid.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import {MatIconModule} from '@angular/material/icon';
import { Ng2GoogleChartsModule} from 'ng2-google-charts';
import { AccumulationChartModule} from '@syncfusion/ej2-angular-charts';
import { GoogleChartsModule } from 'angular-google-charts'; 

@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    DashboardComponent,
    AgGridComponent,
    ArrayOfComponents
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AgGridModule.withComponents([]),
    NgbPaginationModule,
    NgbAlertModule,
    NgbAccordionModule,
    NgbNavModule,
    HttpClientModule,
    MatIconModule,
    Ng2GoogleChartsModule,
    GoogleChartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

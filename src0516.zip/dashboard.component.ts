import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Endpoints} from '../model';
import { GoogleChartsModule } from 'angular-google-charts'; 
import { event } from 'jquery';
import { NgbPanelChangeEvent } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  active = 1;
  nextState: boolean;
  rowData : Endpoints[]= [];
  activeData : Endpoints[]= [];
  inactiveData : Endpoints[]= [];
  teams: any[]=[];
  public activePillIndex:number = 0;

   activeCount = 0;
   inactiveCount =0;

   panelOpenState:boolean;

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.healthcheck();
  }

  columnDefs = [
    {headerName: 'id', field: 'id'},
    {headerName: 'status', field: 'status'},
    {headerName: 'application', field: 'application'},
    {headerName: 'contact', field: 'contac'},
    {headerName: 'healthCheckURL', field: 'healthCheckURL'},
    {headerName: 'modifiedDate', field: 'modifiedDate'},
    {headerName: 'modifiedBy', field: 'modifiedBy'},
    {headerName: 'createdDate', field: 'createdDate'},
    {headerName: 'createdBy', field: 'createdBy'},
    {headerName: 'availability', field: 'availability'},
    {headerName: 'serviceEndpointURL', field: 'serviceEndpointURL'},
    {headerName: 'serviceKey', field: 'serviceKey'}
  ];

  healthcheck(){
    let response = this.http.get<Endpoints[]>("http://localhost:8080/dashboard/healthService/availabilityEndpoints");
    response.subscribe((data : Endpoints[])=>{
      for(let i=0;i<data.length;i++){
        if(data[i].status=='UP'){
          this.activeData.push(data[i]);
        }
        else if(data[i].status=='DOWN'){
          this.inactiveData.push(data[i]);
        }
      }
      for(let i=0;i<data.length;i++){
        if(!this.teams.includes(data[i].contact)){
          this.teams.push(data[i].contact);
        }
      }
      console.log(this.teams);
      console.log(this.activeData);
      console.log(this.inactiveData);
    });
  }

  

  public selectPill(index:number) {
    this.activePillIndex = index;
}

chartTeam(team:string,$event:NgbPanelChangeEvent){
  
this.activeCount = 0;
this.inactiveCount =0;


this.nextState=$event.nextState;

let response = this.http.get<Endpoints[]>("http://localhost:8080/dashboard/healthService/availabilityEndpoints");
    response.subscribe((data : Endpoints[])=>{
      for(let i=0;i<data.length;i++){
        if(data[i].contact==team && data[i].status=="UP"){
            this.activeCount++;
          }
          else if(data[i].contact==team && data[i].status=="DOWN")
            this.inactiveCount++;
      }
      console.log(this.nextState);
      console.log(this.activeCount);
      console.log(this.inactiveCount);
      var cdata = new google.visualization.DataTable();
        cdata.addColumn('string', 'Service');
        cdata.addColumn('number', 'Available');
        cdata.addRows([
          ['Active', this.activeCount],
          ['Inactive',this.inactiveCount]
        ]);
        
        // Set chart options
        var options = {'title':team,
        pieHole: 0.4,
                        colors:['#4CBB17','#FF2400'],
                        'fontSize':11,
                        titleTextStyle: { color: '#00A0DF',fontSize: 15,fontName: 'Helvetica',bold: true },
                       };
        
        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
        chart.draw(cdata, options);
        });
}

}
